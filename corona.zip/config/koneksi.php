<?php
 
$con = mysqli_connect("localhost","id13294561_coronavirus","F9!-a\Ql|cpCp?MO","id13294561_corona");
?>