<?php 
	session_start();
	
	session_destroy();

	echo "<script>alert('Terimakasih telah mengisi survey');</script>";
	echo "<script>document.location.href='../index.php';</script>";
 ?>