<?php
session_start();
require '../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Tes Covid-19</title>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <form method="post">
    <div class="container">
    <table class="table table-striped">
    <h5 align="center">DAFTAR PERTANYAAN</h5>
        <h5 align="center">PENILAIAN RESIKO COVID PRIBADI TERKAIT COVID 19</h5>
        <h6 align="center">Pilih jawaban pada tabel dibawah yang sesuai dengan kegiatan harian anda, untuk bersatu melawan penyebaran COVID 19 selama 14 hari kedepan</h6>
        <thead class="thead-dark">
            <tr>
                <th scope="col">No.</th>
                <th scope="col">K E G I A T A N</th>
                <th scope="col">YA</th>
                <th scope="col">TIDAK</th>
            </tr>
            </thead>
        <tr class="bg-primary">
            <th> A.</th>
            <th>POTENSI TERTULAR DILUAR RUMAH</th>
            <th colspan="2"></th>
        </tr>
        <tr class="bg-warning">
            <td>1</td>
            <td>Saya pergi keluar rumah</td>
            <td><input type="radio" name="a" value="1" required/></td>
            <td><input type="radio" name="a" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>2</td>
            <td>Saya Menggunakan transportasi umum:online,angkot,bus,taksi,kereta api</td>
            <td><input type="radio" name="b" value="1" required/></td>
            <td><input type="radio" name="b" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>3</td>
            <td>Saya tidak memakai masker pada saat berkumpul dengan orang lain</td>
            <td><input type="radio" name="c" value="1" required/></td>
            <td><input type="radio" name="c" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>4</td>
            <td>Saya berjabat tangan dengan orang lain</td>
            <td><input type="radio" name="d" value="1" required/></td>
            <td><input type="radio" name="d" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>5</td>
            <td>Saya tidak membersihkan tangan dengan hand sanitizer/tissue basah sebelum pegang kemudi mobil/motor</td>
            <td><input type="radio" name="e" value="1" required/></td>
            <td><input type="radio" name="e" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>6</td>
            <td>Saya menyentuh benda/uang yang juga disentuh orang lain </td>
            <td><input type="radio" name="f" value="1" required/></td>
            <td><input type="radio" name="f" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>7</td>
            <td>Saya tidak menjaga jarak 1,5 meter dengan orang lain ketika: belanja,bekerja,belajar,ibadah </td>
            <td><input type="radio" name="g" value="1" required/></td>
            <td><input type="radio" name="g" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>8</td>
            <td>Saya makan diluar rumah(warung/restaurant) </td>
            <td><input type="radio" name="h" value="1" required/></td>
            <td><input type="radio" name="h" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>9</td>
            <td>Saya tidak minum air hangat & cuci tangan dengan sabun setelah tiba ditujuan</td>
            <td><input type="radio" name="i" value="1" required/></td>
            <td><input type="radio" name="i" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>10</td>
            <td>Saya berada diwilayah kelurahan tempat pasien tertular </td>
            <td><input type="radio" name="j" value="1" required/></td>
            <td><input type="radio" name="j" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <th>B.</th>
            <th>POTENSI TERTULAR DI DALAM RUMAH :</th>
            <th colspan="2"></th>
        </tr>
        <tr class="bg-primary">
            <td>11</td>
            <td>Saya tidak pasang hand sanitizer didepan pintu masuk, untuk bersihkan tangan sebelum pegang gagang (handle) pintu masuk rumah</td>
            <td><input type="radio" name="k" value="1" required/></td>
            <td><input type="radio" name="k" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>12</td>
            <td>Saya tidak mencuci tangan dengan sabun setelah tiba dirumah</td>
            <td><input type="radio" name="l" value="1" required/></td>
            <td><input type="radio" name="l" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>13</td>
            <td>Saya tidak menyediakan: tissue basah/antiseptic, masker, sabun antiseptic bagi keluarga dirumah</td>
            <td><input type="radio" name="m" value="1" required/></td>
            <td><input type="radio" name="m" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>14</td>
            <td>Saya tidak segera merendam baju & celana bekas pakai diluar rumah kedalam air panas/sabun</td>
            <td><input type="radio" name="n" value="1" required/></td>
            <td><input type="radio" name="n" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>15</td>
            <td>Saya tidak segera mandi keramas setelah saya tiba dirumah</td>
            <td><input type="radio" name="o" value="1" required/></td>
            <td><input type="radio" name="o" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>16</td>
            <td>Saya tidak mensosialisasikan check list penilaian resiko pribadi ini kepada keluarga dirumah</td>
            <td><input type="radio" name="p" value="1" required/></td>
            <td><input type="radio" name="p" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <th>C.</th>
            <th>DAYA TAHAN TUBUH (IMUNITAS):</th>
            <th colspan="2"></th>
        </tr>
        <tr class="bg-warning">
            <td>17</td>
            <td>Saya dalam sehari tidak kena cahaya matahari minimal 15 menit</td>
            <td><input type="radio" name="q" value="1" required/></td>
            <td><input type="radio" name="q" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>18</td>
            <td>Saya tidak jalan kaki/berolah raga minimal 30 menit setiap hari</td>
            <td><input type="radio" name="r" value="1" required/></td>
            <td><input type="radio" name="r" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>19</td>
            <td>Saya jarang minum vitamin C & E, dan kurang tidur</td>
            <td><input type="radio" name="s" value="1" required/></td>
            <td><input type="radio" name="s" value="0" required/></td>
        </tr>
        <tr class="bg-primary">
            <td>20</td>
            <td>Usia saya diatas 60 tahun</td>
            <td><input type="radio" name="t" value="1" required/></td>
            <td><input type="radio" name="t" value="0" required/></td>
        </tr>
        <tr class="bg-warning">
            <td>21</td>
            <td>Saya mempunyai penyakit: jantung/diabetes/gangguan pernafasan kronik</td>
            <td><input type="radio" name="u" value="1" required/></td>
            <td><input type="radio" name="u" value="0" required/></td>
        </tr>
        <tr>
        <td colspan="4" align="center"><button class="btn btn-primary" value="Simpan" name="total">Cek Hasil</button></td>
        </tr>
        <?php 
            if (isset($_POST['total'])){

                $total = $_POST['a'] + $_POST['b'] + $_POST['c'] + $_POST['d'] + $_POST['e'] + $_POST['f'] + $_POST['g'] + $_POST['h'] + $_POST['i'] + $_POST['j'] + $_POST['k'] + $_POST['l'] + $_POST['m'] + $_POST['o'] + $_POST['p'] + $_POST['q'] + $_POST['r'] + $_POST['s']+ $_POST['t']+ $_POST['u'];
                if($total >=15){
                    $resiko = "Tinggi";
                } elseif ($total >= 8){
                    $resiko = "Sedang";
                } elseif ($total >= 0){
                    $resiko = "Rendah";
                } else {
                    echo "kosong";
                }
                $sql = mysqli_query($con, "INSERT INTO tb_identitas VALUES('','$_SESSION[nama]','$_SESSION[usia]','$_SESSION[jk]','$_SESSION[alamat]','$total','$resiko')");
                if ($sql){
                    $_SESSION['resiko'] = $resiko;
                    echo "<script>document.location.href='hasil_survey.php';</script>";
                }
            }
        ?>
    </table>
    </div>
    </form>
</body>
</html>