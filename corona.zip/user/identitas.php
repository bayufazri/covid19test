<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style type="text/css">
           body {
	color: #fff;
	background: url('../img/covid19.png');
	background-size: cover;
}
    </style>
    <title>Data diri</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<?php
session_start();
include "../config/koneksi.php";

if (isset($_POST['mulai'])) {
    $_SESSION['nama'] = $_POST['nama'];
    $_SESSION['usia'] = $_POST['usia'];
    $_SESSION['jk'] = $_POST['jk'];
    $_SESSION['alamat']= $_POST['alamat'];
    echo "<script>;document.location.href='survey.php';</script>";
}

?>
<h1></h1>
<div class="container">
<div class="card" >
    <div class="card-header bg-primary text-white"><h4>Isi Identitas Terlebih Dahulu<h4></div>
    <div class="card-body">		 
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="nama">Nama Anda :</label>
				<input type="text" class="form-control" name="nama" id="nama" required>
			</div>
            <div class="form-group">
				<label for="nama">Usia :</label>
				<input type="text" class="form-control" name="usia" id="usia" required>
			</div>
				<label for="nama">Jenis kelamin :</label>
            <div class="radio-inline">
                <label><input type="radio" name="jk" value="laki-laki" required> Laki-laki </label>
                <div class="radio-inline">
                <label><input type="radio" name="jk" value= "Perempuan" required> Perempuan</label>
                </div>
                </div>
			<div class="form-group">
				<label for="alamat">Alamat :</label>
				<input type="text" class="form-control" id="alamat" name="alamat" required>
			</div>		
                <button type="submit" class="btn btn-outline-primary" value="Simpan" name="mulai" required>Lanjut</button>

		</form>
        </div>
        </div>
	</div>
</body>
</html>