<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style type="text/css">
        body {
	color: #fff;
	background: url('../img/covid19.png');
	background-size: cover;
}
        
    </style>
    <title>Hasil Survey</title>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<div class="container">

<h1></h1>
<div class="card text-white bg-warning mb-3" style="max-width: 1100px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="../img/gambar.jpg" class="card-img" alt="...">
    </div>
    <div class="col-md-8">
  <div class="card-body">
    <h5 class="card-title"><?php echo "Anda Beresiko ".@$_SESSION['resiko'];?></h5>
    <h2>Terkena penyakit COVID 19 ini !</h2>
    <p class="card-text">Tetap jaga kesehatan dan patuhi kebijakan pemerintah demi mengurangi peyebaran COVID 19</p>
    <a href="logout.php" class="btn btn-outline-primary">Selesai</a>
  </div>
  </div>
</div>
</html>